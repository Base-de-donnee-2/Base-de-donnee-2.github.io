import mysql.connector as mysql
import os
from dataclasses import dataclass

db_config = {
    'host' : 'localhost',
    'user' : 'root',
    'password' : 'r00t_bd2',
    'database' : 'bd2_examenfinalformatif'
}

@dataclass
class Questionnaire:
  id: int
  titre: str
  description: str
  pointageCalcule: int 

# Pour les besoins de l'examen et de la contrainte du temps
# on va prendre pour acquis qu'on travaille dans le questionnaire
# avec le id 1. On ne gèrera pas le choix du questionnaire.
idQuestionnaireActif = 1 

# Permet d'effacer la console
def cls():
    os.system('cls' if os.name=='nt' else 'clear')

def SelectionneQuestionnaire(questionnaireId):
    questionnaire = Questionnaire(-1,'','','')
    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        query = "select id, titre, description, pointage_calcule from questionnaire where id = %(id)s;"
        cursor.execute(query, { 'id' : questionnaireId })

        result = cursor.fetchone()

        if result:
            questionnaire = Questionnaire(result[0], result[1], result[2], result[3])

    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

    return questionnaire

def SelectQuestion(questionId):
    """
    Sélectionne une question
    Arguments:
        id: le id de la question (integer)
    Returns:
        Un tuple avec le nom, la classe et le score d'un citoyen
    """
    query = """
        SELECT texte_question, obligatoire, pointage, type_question_id 
        FROM question
        WHERE id = %(question_id)s;
    """
    parametres = {
        'question_id' : questionId
        }
    result = []

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(query, parametres)
        result = cursor.fetchone()
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

    return result

def SelectReponseChoix(questionId):
    query = """
        SELECT texte_choix, bonne_reponse FROM question_choix WHERE question_id = %(question_id)s ORDER BY ordre;
    """
    parametres = {
        'question_id' : questionId
        }
    result = []

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(query, parametres)
        result = cursor.fetchall()
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

    return result

def SelectReponseTexte(questionId):
    query = """
        SELECT reponse FROM question_texte_reponse WHERE question_id = %(question_id)s;
    """
    parametres = {
        'question_id' : questionId
        }
    result = []

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(query, parametres)
        result = cursor.fetchall()
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

    return result

def AfficherQuestion():
    # Question 1
    # Demande le id de la question à l'usager
    questionId = input("Entrez le id de la question à consuter : ")
    # Récupère la question
    question = SelectQuestion(questionId)
    # Continuer seulement si un question est retournée
    if question:
        # Récupère le type de question pour les autres requêtes
        typeId = question[3]
        obligatoire = "*" if question[1] else ""
        # Affiche le texte de la question
        print("\n{0} {1} ({2} points)".format(question[0], obligatoire, question[2]))

        if(typeId == 1):
            # Question à choix multiple
            reponses = SelectReponseChoix(questionId)
            print("Question à choix")
            for (texte_choix, bonne_reponse) in reponses:
                print("- {0} {1}".format(texte_choix, "(bonne réponse)" if bonne_reponse == True else ""))
        elif(typeId == 2):
            # Question texte
            reponses = SelectReponseTexte(questionId)
            print("Question texte")
            listeReponse = ""
            for (reponse,) in reponses:
                listeReponse += "{0}, ".format(reponse)
                # listeReponse[:-2] va enlever les 2 derniers caractères de listeReponse
            print("Bonne réponse : {0}".format(listeReponse[:-2]))

def insertReponseChoix(question_id, texte_choix, bonne_reponse, ordre):
    query = """
        INSERT INTO question_choix(question_id, texte_choix, bonne_reponse, ordre) 
        VALUES(%(question_id)s, %(texte_choix)s, %(bonne_reponse)s, %(ordre)s);
    """
    parametre = {
        'question_id' : question_id,
        'texte_choix' : texte_choix,
        'bonne_reponse' : bonne_reponse,
        'ordre' : ordre,
    }

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(query, parametre)

        connection.commit()
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

def insertReponseTexte(question_id, texte_reponse):
    query = """
        INSERT INTO question_texte_reponse(question_id, reponse)
        VALUES(%(question_id)s, %(texte_reponse)s);
    """
    parametre = {
        'question_id' : question_id,
        'texte_reponse' : texte_reponse,
    }

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute(query, parametre)

        connection.commit()
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

def deleteQuestion(question_id):
    questionDelete = False

    try:
        connection = mysql.connect(**db_config)
        cursor = connection.cursor()

        parametres = [question_id]
        cursor.callproc('suppressionQuestion', parametres)

        questionDelete = True
    except mysql.Error as erreur:
        print(erreur)
    finally:
        cursor.close()
        connection.close()

    return questionDelete

def AjouterReponse():
    # Question 2
    questionId = input("Entrez le id de la question dont on veut ajouter une réponse : ")
    texteQuestion = input("Quel est le texte de la question à ajouter : ")
    typeQuestion = input("Est-ce que c'est une question à choix de réponse (o/n) : ")
    bonneReponse = 1 if input("Est-ce la bonne réponse (o/n) : ") == "o" else "0"
    ordre = input("Quel est l'ordre de la réponse : ")

    if(typeQuestion == "o"):
        # Question à choix multiple
        insertReponseChoix(questionId, texteQuestion, bonneReponse, ordre)
    else:
        insertReponseTexte(questionId, texteQuestion)

def SupprimerQuestion():
    # Question 3
    questionId = input("Entrez le id de la question qu'on veut supprimer : ")
    if(deleteQuestion(questionId)):
        print("La question id({}) a été supprimé".format(questionId))

def OptionMenu():
    choix = 0
    questionnaire = SelectionneQuestionnaire(idQuestionnaireActif)
    texteMenu = """ 
        Gestion des questionnaires

        {0}
        {1}

            1- Afficher une question
            2- Ajouter une réponse
            3- Supprimer une question
            4- Quitter

        Veuillez choisir une option : 
        """.format(questionnaire.titre, questionnaire.description)

    try:
        choix = int(input((texteMenu)))
    except ValueError:
        print("Le choix est invalide")
    return choix


def AfficherMenuPrincipale():
    while True:
        choixMenu = OptionMenu()

        if choixMenu == 1:
            AfficherQuestion()

        if choixMenu == 2:
            AjouterReponse()

        if choixMenu == 3:
            SupprimerQuestion()

        if choixMenu == 4:
            print("Goodbye!!")
            break

if __name__ == "__main__":
    AfficherMenuPrincipale()