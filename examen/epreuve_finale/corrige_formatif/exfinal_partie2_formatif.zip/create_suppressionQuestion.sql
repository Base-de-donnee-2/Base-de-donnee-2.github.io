DELIMITER $$

CREATE PROCEDURE suppressionQuestion(_question_id INT)
BEGIN
	
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		SELECT 0 as resultat;
	END;
	
	
	START TRANSACTION;
	
	DELETE FROM question_choix WHERE question_id = _question_id;
	DELETE FROM question_texte_reponse WHERE question_id = _question_id;
	DELETE FROM question WHERE id = _question_id;

	COMMIT;

	SELECT 1 as resultat;
END$$

DELIMITER ;