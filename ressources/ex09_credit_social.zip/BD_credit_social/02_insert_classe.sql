insert into credit_social.classe (titre, credit_min)
values ('Alpha',950),
	   ('Beta',800),
	   ('Gamma',600),
	   ('Delta',350),
	   ('Epsilon',0);