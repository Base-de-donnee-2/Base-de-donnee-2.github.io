DROP DATABASE IF EXISTS credit_social;
CREATE DATABASE credit_social;
use credit_social;

-- Cr�ation des tables
create table if not exists credit_social.classe (
	id INT auto_increment NOT NULL,
	titre varchar(20) NOT NULL,
	credit_min INT NOT NULL,
	CONSTRAINT classe_pk PRIMARY KEY (id)
);

create table if not exists credit_social.evenement_type (
	id INT auto_increment NOT NULL,
	titre varchar(100) NOT NULL,
	score_defaut INT NOT NULL,
	CONSTRAINT evenement_type_pk PRIMARY KEY (id)
);

create table if not exists credit_social.log_update_classe (
	id INT auto_increment NOT NULL,
	date_update DATETIME NOT NULL,
	citoyen_id INT NOT NULL,
	ancienne_classe_id INT NOT NULL,
	nouvelle_classe_id INT NOT NULL,
	CONSTRAINT log_update_classe_pk PRIMARY KEY (id)
);

create table if not exists credit_social.citoyen (
	id INT auto_increment NOT NULL,
	classe_id INT NOT NULL,
	nom varchar(100) NOT NULL,
	prenom varchar(100) NOT NULL,
	no_civique INT NULL,
	adresse varchar(255) NULL,
	ville varchar(100) NULL,
	pin varchar(100) NOT NULL,
	credit_initial INT not null,
	CONSTRAINT citoyen_pk PRIMARY KEY (id),
	CONSTRAINT citoyen_FK FOREIGN KEY (classe_id) REFERENCES credit_social.classe(id)
);

create table if not exists credit_social.evenement (
	id INT auto_increment NOT NULL,
	type_evenement_id INT NOT NULL,
	date_evenement DATETIME NOT NULL,
	notes varchar(10000) NULL,
	CONSTRAINT evenement_pk PRIMARY KEY (id),
	CONSTRAINT evenement_FK FOREIGN KEY (type_evenement_id) REFERENCES credit_social.evenement_type(id)
);

create table if not exists credit_social.citoyen_evenement (
	id INT auto_increment not null,
	citoyen_id INT NOT NULL,
	evenement_id INT NOT NULL,
	score_ajustement INT NULL,
	CONSTRAINT citoyen_evenement_pk PRIMARY KEY (id)
);



