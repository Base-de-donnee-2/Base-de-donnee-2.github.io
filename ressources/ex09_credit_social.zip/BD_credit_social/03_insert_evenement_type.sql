insert into credit_social.evenement_type (titre, score_defaut)
values ('Reunion du parti',10),
	   ('Denonciation', 25),
	   ('Realignement sanitaire', 20),
	   ('Manifestation', -100),
	   ('Idees dissidentes', -50),
	   ('Comportement reprehensible', -25)